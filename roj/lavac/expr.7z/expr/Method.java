package roj.lavac.expr;

import roj.asm.Opcodes;
import roj.asm.tree.MethodNode;
import roj.asm.tree.insn.InvokeInsnNode;
import roj.asm.type.ParamHelper;
import roj.asm.type.Type;
import roj.lavac.parser.MethodPoetL;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * 操作符 - 调用方法
 *
 * @author Roj233
 * @since 2022/2/27 20:54
 */
public class Method implements Expression {
	public static final int INVOKE_SPECIAL = 1, PRECOMPILE = 4;

	Expression load;
	MethodNode method;
	List<Expression> args;
	byte flag;

	public Method(Expression load, MethodNode method, List<Expression> args, int flag) {
		this.load = load;
		this.method = method;
		this.args = args;
		this.flag = (byte) flag;
	}

	@Override
	public boolean isEqual(Expression left) {
		if (this == left) return true;
		if (left == null || getClass() != left.getClass()) return false;
		Method m = (Method) left;
		return m.method.equals(method) && (m.flag & 1) == (flag & 1) && ArrayDef.arrayEq(args, m.args);
	}

	@Override
	public void write(MethodPoetL tree, boolean noRet) {
		this.load.write(tree, false);
		compressArg();
		for (int i = 0; i < args.size(); i++) {
			Expression expr = args.get(i);
			expr.write(tree, false);
		}

		if (method.name().equals("<init>")) {
			tree.new1(method.ownerClass()).dup().node(new InvokeInsnNode(Opcodes.INVOKESPECIAL, method.ownerClass(), "<init>", method.rawDesc()));
		} else {
			// todo
			tree.node(new InvokeInsnNode(Opcodes.INVOKESPECIAL, method.ownerClass(), method.name(), method.rawDesc()));
		}
	}

	private void compressArg() {
		if ((flag & 8) == 0) {
			List<Expression> args = this.args;
			for (int i = 0; i < args.size(); i++) {
				Expression cp = args.get(i).compress();
				if (!cp.isConstant()) flag |= 16;
				args.set(i, cp);
			}
			flag |= 8;
		}
	}

	@Nonnull
	@Override
	public Expression compress() {
		compressArg();

		if ((flag & 16) == 0) {
			// 为预编译预留
		}

		return this;
	}

	@Override
	public Type type() {
		return ParamHelper.parseReturn(method.rawDesc());
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (method.name().equals("<init>")) {
			sb.append("new ").append(method.ownerClass());
		} else {
			sb.append(method.name());
		}
		sb.append('(');
		if (!args.isEmpty()) {
			int i = 0;
			while (true) {
				sb.append(args.get(i++));
				if (i == args.size()) break;
				sb.append(',');
			}
		}
		return sb.append(')').toString();
	}
}
