package roj.lavac.expr;

import roj.asm.Opcodes;
import roj.asm.frame.MethodPoet;
import roj.asm.frame.VarType;
import roj.asm.tree.anno.AnnValDouble;
import roj.asm.tree.anno.AnnValFloat;
import roj.asm.tree.anno.AnnValInt;
import roj.asm.tree.anno.AnnValLong;
import roj.asm.type.Type;
import roj.concurrent.OperationDone;
import roj.config.word.NotStatementException;
import roj.lavac.parser.MethodPoetL;

import javax.annotation.Nonnull;

import static roj.lavac.parser.Tokens.*;

/**
 * 一元运算符
 *
 * @author Roj233
 * @since 2022/3/1 19:59
 */
public final class UnaryPrefix implements Expression {
	private final short operator;
	private Expression right;

	public UnaryPrefix(short operator) {
		switch (operator) {
			default:
				throw new IllegalArgumentException("Unsupported operator " + operator);
			case logic_not:
			case rev:
			case inc:
			case dec:
			case add:
			case sub:
		}
		this.operator = operator;
	}

	@Override
	public void write(MethodPoetL tree, boolean noRet) {
		switch (operator) {
			case logic_not:
			case sub:
			case add:
			case rev:
				if (noRet) throw new NotStatementException();
				// those could only be used inside expr...

				right.write(tree, false);

				switch (operator) {
					case logic_not:
						tree.const1(1).xor();
						break;
					case sub:
						tree.neg();
						break;
					case rev:
						if (tree.stackTop().type == VarType.LONG) {
							tree.const1(-1L).xor();
						} else {
							tree.const1(-1).xor();
						}
						break;
					case add:
					default:break;
				}
				break;
			case inc:
			case dec:
				int c = operator == inc ? 1 : -1;
				switch (((LoadExpression) this.right).loadType()) {
					case LoadExpression.VARIABLE: {
						Variable v = (Variable) this.right;

						MethodPoet.Variable name = v.v;

						tree.increment(name, c);
						if (!noRet) {
							tree.load(name);
						}

						v._after_write_op(tree);
					}
					break;
					case LoadExpression.STATIC_FIELD: {
						StaticField v = (StaticField) this.right;
						v.write(tree, false); // load
						tree.const1(c).add();
						if (!noRet) tree.dup();
						v.write2(tree); // store
					}
					break;
					case LoadExpression.DYNAMIC_FIELD: {
						Field v = (Field) this.right;
						v.write2(tree);
						tree.const1(c).add();
						if (!noRet) tree.dupX1();
						v.write3(tree);
					}
					break;
					case LoadExpression.ARRAY: {
						ArrayGet v = (ArrayGet) this.right;
						v.write2(tree); // array, index
						tree.noPar(Opcodes.DUP2).arrayLoad().const1(c).add();
						if (!noRet) tree.dupX1();
						tree.arrayStore();
					}
					break;
				}
				break;
		}
	}

	@Override
	public boolean isConstant() {
		return operator != inc && operator != dec && right.isConstant();
	}

	@Nonnull
	@Override
	public Expression compress() {
		if (right == null) throw new IllegalArgumentException("Missing right");

		if (operator == sub && right instanceof UnaryPrefix) {
			UnaryPrefix p = (UnaryPrefix) right;
			if (p.operator == sub) { // - - a
				return p.right.compress();
			}
		}

		// inc/dec不能对常量使用, 所以不用管了
		if (!(right = right.compress()).isConstant()) return this;
		if (operator == add) return right;

		LDC cst = right.asCst();

		switch (right.type().type) {
			case Type.BYTE:
			case Type.SHORT:
			case Type.CHAR:
			case Type.BOOLEAN:
			case Type.INT:
				switch (operator) {
					case logic_not:
						return LDC.valueOf(((AnnValInt) cst.val()).value == 0);
					case rev: {
						AnnValInt v = (AnnValInt) cst.val();
						v.value = ~v.value;
						return right;
					}
					case sub: {
						AnnValInt v = (AnnValInt) cst.val();
						v.value = -v.value;
						return right;
					}
				}
				break;
			case Type.LONG:
				switch (operator) {
					case rev: {
						AnnValLong v = (AnnValLong) cst.val();
						v.value = ~v.value;
						return right;
					}
					case sub: {
						AnnValLong v = (AnnValLong) cst.val();
						v.value = -v.value;
						return right;
					}
				}
				break;
			case Type.FLOAT: {
				AnnValFloat v = (AnnValFloat) cst.val();
				v.value = -v.value;
				return right;
			}
			case Type.DOUBLE: {
				AnnValDouble v = (AnnValDouble) cst.val();
				v.value = -v.value;
				return right;
			}
		}
		throw OperationDone.NEVER;
	}

	@Override
	public Type type() {
		return right.type();
	}

	@Override
	public boolean isEqual(Expression left) {
		if (this == left) return true;
		if (!(left instanceof UnaryPrefix)) return false;
		UnaryPrefix left1 = (UnaryPrefix) left;
		return left1.right.isEqual(right) && left1.operator == operator;
	}

	@Override
	public String toString() {
		return byId(operator) + ' ' + right;
	}

	public String setRight(Expression right) {
		if (right == null) return "upf: right is null";

		if (!(right instanceof Field) && !(right instanceof ArrayGet)) {
			switch (operator) {
				case inc:
				case dec:
					return "unary.expecting_variable";
			}
		}

		this.right = right;

		return null;
	}
}
