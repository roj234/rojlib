package roj.lavac.expr;

import roj.asm.tree.anno.AnnVal;
import roj.asm.util.ConstantPool;
import roj.util.ByteList;
import roj.util.DynByteBuf;

/**
 * 用注解的类型，省得新建那么多类型包装
 *
 * @author Roj233
 * @since 2022/2/27 19:51
 */
public class AnnValNull extends AnnVal {
	public static final AnnValNull INST = new AnnValNull();
	public static final byte NULL = 'N';

	@Override
	public byte type() {
		return NULL;
	}

	@Override
	public void toByteArray(ConstantPool pool, DynByteBuf w) {
		throw new RuntimeException("Not suitable when annotation kind != SOURCE");
	}

	@Override
	public String toString() {
		return "null";
	}

	@Override
	public boolean equals(Object obj) {
		return obj == this;
	}

	@Override
	public int hashCode() {
		return 1919810;
	}
}
