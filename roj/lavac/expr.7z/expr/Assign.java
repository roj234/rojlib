package roj.lavac.expr;

import roj.asm.tree.anno.AnnVal;
import roj.asm.tree.anno.AnnValDouble;
import roj.asm.tree.anno.AnnValInt;
import roj.asm.type.Type;
import roj.kscript.asm.Opcode;
import roj.kscript.parser.Tokens;
import roj.kscript.type.KDouble;
import roj.lavac.parser.MethodPoetL;
import roj.lavac.parser.Tokens;

import javax.annotation.Nonnull;

import static roj.asm.type.Type.*;

/**
 * 操作符-赋值
 *
 * @author Roj233
 * @since 2020/10/15 13:01
 */
public final class Assign implements Expression {
	LoadExpression left;
	Expression right;

	public Assign(LoadExpression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	@Nonnull
	@Override
	public Expression compress() {
		left = (LoadExpression) left.compress();
		right = right.compress();
		return this;
	}

	@Override
	@SuppressWarnings("fallthrough")
	public void write(MethodPoetL tree, boolean noRet) {
		boolean var = left instanceof Variable;
		boolean opDone = false;

		mutateSelf:
		if (right instanceof Binary) {
			Binary bin = (Binary) right;

			Expression ar;
			if (bin.left.isEqual(left)) {
				ar = bin.right;
			} else if (bin.right.isEqual(left)) {
				ar = bin.left;
			} else {
				break mutateSelf;
			}

			switch (bin.operator) {
				case Tokens.logic_or:
				case Tokens.logic_and:
					break;
				case Tokens.add:
				case Tokens.dec:
					// i = i + 1 or i += 1; but not i++
					if (ar.isConstant()) {
						AnnVal val = ar.asCst().val();
						switch (val.type()) {
							case SHORT:
							case CHAR:
							case BOOLEAN:
							case BYTE:
							case INT:
								int i = ((AnnValInt) val).value;
								if (bin.operator != Tokens.add) i = -i;

								if (var) {
									Variable v = (Variable) this.left;
									tree.increment(v.v, i);
									v._after_write_op(tree);
									if (!noRet) tree.load(v.v);
								} else {
									left.write2(tree);

									tree.Std(Opcode.DUP2).Std(Opcode.GET_OBJ).Load(KDouble.valueOf(i)).Std(bin.operator == Tokens.add ? Opcode.ADD : Opcode.SUB);
									if (!noRet) {
										tree.Std(Opcode.DUP).Std(Opcode.SWAP3);
									}
									tree.Std(Opcode.PUT_OBJ);
								}

								opDone = true;

								break;
							case DOUBLE:
								double i = ((AnnValDouble) val).value;
								if (bin.operator != Tokens.add) i = -i;

								left.write2(tree);

								tree.Std(Opcode.DUP2).Std(Opcode.GET_OBJ).Load(KDouble.valueOf(i)).Std(bin.operator == Tokens.add ? Opcode.ADD : Opcode.SUB);
								if (!noRet) {
									tree.Std(Opcode.DUP).Std(Opcode.SWAP3);
								}
								tree.Std(Opcode.PUT_OBJ);

								opDone = true;
								break;
							case LONG:

								break;
							case FLOAT:

								break;
							case CLASS:
								// 为自定义操作符预留
								break;
						}
						break;
					}
				default:
					// etc. k = k * 3;
					if (!var) {
						left.write2(tree);

						ar.write(tree.Std(Opcode.DUP2).Std(Opcode.GET_OBJ), false);
						bin.writeOperator(tree);

						if (!noRet) {
							tree.Std(Opcode.DUP).Std(Opcode.SWAP3);
						}

						tree.Std(Opcode.PUT_OBJ);

						opDone = true;
					}
					break;
			}
		}

		if (!opDone) {
			if (var) {
				right.write(tree, false);
				Variable v = (Variable) this.left;
				tree.Set(v.field);
				v._after_write_op(tree);
				if (!noRet) tree.Get(v.field);
			} else {
				// parent name value
				left.write2(tree);
				right.write(tree, false);
				if (!noRet) {
					tree.Std(Opcode.DUP).Std(Opcode.SWAP3);
				}
				tree.Std(Opcode.PUT_OBJ);
			}
		}
	}

	@Override
	public Type type() {
		return left.type();
	}

	@Override
	public boolean isEqual(Expression left) {
		if (this == left) return true;
		if (!(left instanceof Assign)) return false;
		Assign assign = (Assign) left;
		return assign.left.isEqual(left) && assign.right.isEqual(right);
	}

	@Override
	public String toString() {
		return left.toString() + '=' + right;
	}
}
