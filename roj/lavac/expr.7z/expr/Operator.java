package roj.lavac.expr;

import roj.asm.type.Type;
import roj.lavac.parser.MethodPoetL;
import roj.lavac.parser.Tokens;

/**
 * 临时操作符1 - 保存运算符
 *
 * @author Roj233
 * @since 2022/3/1 19:14
 */
public final class Operator implements Expression {
	public final short operator;

	static final Operator[] table;

	static {
		table = new Operator[Tokens.operators.length];
		for (int i = 0; i < table.length; i++) {
			table[i] = new Operator(i + 101);
		}
	}

	private Operator(int operator) {
		this.operator = (short) operator;
	}

	public static Operator retain(short op) {
		return table[op - 101];
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Operator tmp = (Operator) o;
		return operator == tmp.operator;
	}

	@Override
	public int hashCode() {
		return operator;
	}

	@Override
	public void write(MethodPoetL tree, boolean noRet) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Type type() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isEqual(Expression left) {
		return false;
	}

	@Override
	public String toString() {
		return "~{" + Tokens.byId(operator) + '}';
	}
}