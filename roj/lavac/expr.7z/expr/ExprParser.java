package roj.lavac.expr;

import roj.asm.tree.insn.LabelInsnNode;
import roj.asm.type.Generic;
import roj.asm.type.Type;
import roj.asm.type.IType;
import roj.collect.Int2IntMap;
import roj.collect.MyHashMap;
import roj.collect.SimpleList;
import roj.config.ParseException;
import roj.config.word.GenericLexer;
import roj.config.word.Word;
import roj.config.word.WordPresets;
import roj.lavac.parser.*;
import roj.text.CharList;
import roj.util.Helpers;

import javax.annotation.Nullable;
import java.util.*;

import static roj.lavac.parser.Tokens.*;

/**
 * 操作符优先级靠它实现
 *
 * @author Roj233
 * @since 2020/10/13 22:14
 */
public final class ExprParser {
	private final ArrayList<Expression> words = new ArrayList<>();
	private final Int2IntMap ordered = new Int2IntMap();
	private final ArrayList<Int2IntMap.Entry> sort = new ArrayList<>();
	private boolean busy;
	private ExprParser next;
	ExprParser next() {
		if (next != null) return next;
		ExprParser ep = new ExprParser(depth+1);
		if (depth < 10) next = ep;
		return ep;
	}

	private final int depth;

	static final boolean SORT_CST = System.getProperty("kscript.sortConstant", "true").equalsIgnoreCase("true");
	static final Comparator<Int2IntMap.Entry> sorter = (a, b) -> {
		return Integer.compare(b.v, a.v);
	};

	public ExprParser(int depth) {
		this.depth = depth;
	}

	/**
	 * 解析数组定义 <BR>
	 * {xx, yyy, zzz} or {}
	 */
	public Expression defineArray(CompileUnit ctx, short flag) throws ParseException {
		JavaLexer wr = ctx.getLexer();
		List<Expression> expr = new ArrayList<>();

		// todo ??
		boolean hasMore = true;
		try {
			hasMore = wr.offset(1) != '}';
		} catch (ArrayIndexOutOfBoundsException ignored) {
		}

		Word w;
		o:
		while (true) {
			w = wr.nextWord();
			switch (w.type()) {
				case right_l_bracket:
					break o;
				case comma:
					if (hasMore) {
						wr.unexpected(",");
					}
					hasMore = true;
					continue;
				default:
					wr.retractWord();
					break;
			}

			hasMore = false;

			Expression result = read(ctx, (short) 128, null);
			if (result != null) {
				expr.add(result);
			} else {
				if (wr.nextWord().type() != right_l_bracket) {
					wr.unexpected("empty_statement");
				}
				break;
			}
		}

		return new ArrayDef(expr);
	}

	/**
	 * 解析对象定义 <BR>
	 * {xxx: yyy, zzz: uuu}
	 */
	public Expression pythonCall(CompileUnit ctx, int flag) throws ParseException {
		JavaLexer wr = ctx.getLexer();
		MyHashMap<String, Expression> map = new MyHashMap<>();

		boolean hasMore = true;
		try {
			hasMore = wr.offset(1) != '}';
		} catch (IndexOutOfBoundsException ignored) {
		}

        /*
          Map map = new Map();
          map.put(LoadData name, Expr xxx);
          ...
         */
		Word w;
		o:
		while (true) {
			Word name = wr.nextWord();
			switch (name.type()) {
				case right_l_bracket:
					break o;
				case comma:
					if (hasMore) {
						wr.unexpected(",");
					}
					hasMore = true;
					continue;

				case WordPresets.STRING:
				case WordPresets.LITERAL:
					break;
				default:
					wr.unexpected(name.val(), "type.string");
			}

			final Word wd = wr.nextWord();
			if (wd.type() != colon) wr.unexpected(wd.val(), ":");

			Expression result = read(ctx, (short) 64, null);

			boolean end = wr.nextWord().type() == right_l_bracket;

			if (result != null) {
				map.put(name.val(), result);
			} else {
				wr.unexpected("empty_statement");
			}

			if (end) {
				break;
			}
			wr.retractWord();
		}
		
		
		return null;
	}

	/**
	 * @see #read(CompileUnit, short, LabelInsnNode)
	 */
	@Nullable
	public Expression read(CompileUnit ctx, int exprFlag) throws ParseException {
		try {
			return read0(ctx, exprFlag, null, null);
		} finally {
			busy = false;
		}
	}

	@SuppressWarnings("fallthrough")
	@Nullable
	public Expression read(CompileUnit ctx, int exprFlag, LabelInsnNode ifFalse) throws ParseException {
		try {
			return read0(ctx, exprFlag, ifFalse, null);
		} finally {
			busy = false;
		}
	}

	private Expression _new(CompileUnit ctx, int flags) throws ParseException {
		// new Type.
		IType type = ctx.resolveGenericallyType(CompileUnit.TYPE_PRIMITIVE);
		if (type.genericType() != 0) {
			Generic g = (Generic) type;
			if (g.array() > 0) {
				throw ctx.getLexer().err("generic_array");
			}
		}
		if (type) System.out.println(Arrays.toString(new MyHashMap<?,Object>[1]));
	}

	private Expression variableMethodFieldDeclare(JavaLexer wr, String begin) throws ParseException {
		CharList tmp = CompileLocalCache.get().tmpList; tmp.clear();

		SimpleList<String> list = new SimpleList<>(3);
		list.capacityType = 2;
		list.add(begin);

		int flag = 0;

		Word w = wr.nextWord();
		while (w.type() == dot) {
			w = wr.nextWord();
			// todo: support a?.x, automatic nullability check
			switch (w.type()) {
				case WordPresets.LITERAL:
					list.add(w.val());
					break;
				default:
					wr.unexpected(w.val(), "////");
			}
			w = wr.nextWord();
		}

		switch (w.type()) {
			case left_m_bracket: // method invocation
			case left_s_bracket: // array declare or get

		}

		throw wr.err("unexpected:eof");
	}

	static final int OP_DOT = 1, OP_OBJECT = 2, OB_PRIMITIVE = 4;
	/**
	 * Expression parser(表达式解析器) <BR>
	 * 逻辑烦死人 <BR>
	 * 但是做好了之后感觉我太NB了! <BR>
	 *
	 * @param exprFlag <BR>
	 * 8   : in 解析数组索引 <BR>
	 * 16  : in 解析函数调用参数 <BR>
	 * 32  : in 解析if中的内容(为了压缩) <BR>
	 * 64  : in 定义对象 {xxx} <BR>
	 * 128 : in 定义数组 <BR>
	 * 256 : in 解析括号优先 <BR>
	 * 512 : in 三元运算符 - ? <BR>
	 * 1024: in for <BR>
	 * 2048: 逗号连接模式 <BR>
	 * 4096: 右值 <BR>
	 *
	 * @throws ParseException if error occurs.
	 */
	private Expression read0(CompileUnit ctx, short exprFlag, LabelInsnNode ifFalse, Type excepting) throws ParseException {
		ArrayList<Expression> tmp = words;
		if (busy) {
			try {
				return next().read0(ctx, exprFlag, ifFalse, excepting);
			} finally {
				if (next != null) next.busy = false;
			}
		}
		busy = true;

		JavaLexer wr = ctx.getLexer();

		Expression cur = null;
		// 这TM其实是个链表
		UnaryPrefix pf = null, pfTop = null;

		Word w;

		/**
		 *    1   : 有'.' <BR>
		 *    2   : 当前是对象类型 <BR>
		 *    4   : 当前是基本类型 <BR>
		 *    8   : new <BR>
		 *    16  : delete <BR>
		 *    32  : 逗号连接模式 <BR>
		 */
		int opFlag = 0;

		wr.flag = 0;

		/**
		 * EXPRESSION:
		 * 	UNION {
		 * 	    A {
		 * 			REPEAT { LITERAL "." }
		 * 			union {
		 * 			 	   name(METHOD) "("
		 * 			 	   REPEAT{
		 * 			 	       EXPRESSION ","
		 * 			 	   }
		 * 			 	   ")"
		 * 			}
		 * 	    }
		 * 	}
		 *
		 */

		o:
		while (true) {
			w = wr.nextWord();
			switch (w.type()) {
				case NEW:
					if (cur != null || (opFlag != 0)) wr.unexpected(w.val(), "empty");
					opFlag |= 8;
					break;
				// [ x ]
				case left_m_bracket: {// array start
					if ((opFlag & 5) != 0) wr.unexpected("[");

					if (cur == null) {
						if ((opFlag & 16) != 0) wr.unexpected("[");

						// define array
						cur = defineArray(ctx, exprFlag);
						opFlag |= 2;
					} else {
						if ((opFlag & 2) == 0) wr.unexpected("[");
						// get array
						Expression index = read(ctx, (short) 8, null);
						if (index == null) {
							wr.unexpected("empty.array_index");
						}

						cur = new ArrayGet(cur, index);
					}
				}
				break;
				// a.b.c.d
				case WordPresets.LITERAL: {
					if (cur == null) {
						cur = new Variable(ctx.resolveTypeLike(0));
						cur.mark_spec_op(ctx, 1);
					} else {
						// not first

						if ((opFlag & 4) != 0) {
							wr.unexpected(w.val());
						}
						if ((opFlag & 1) == 0) wr.unexpected(w.val(), ".");
						opFlag &= ~1;
						cur = new Field(cur, w.val());
					}
					opFlag |= 2;
				}
				break;
				// this
				case THIS: {
					if (cur == null) {
						cur = Std.STD1;
						opFlag |= 2;
					} else {wr.unexpected("this");}
				}
				break;
				// constant
				//case Keyword.HEX:       // 十六进制
				//case Keyword.BINARY:    // 二进制
				//case Keyword.OCTAL:     // 八进制
				case WordPresets.INTEGER: { // 整数
					if (cur != null) {wr.unexpected(w.val(), "type.get_able");} else {
						cur = Constant.valueOf(w);
						opFlag |= 4;
					}
				}
				break;
				case WordPresets.CHARACTER:
				case WordPresets.STRING:
				case WordPresets.DECIMAL_D:
				case WordPresets.DECIMAL_F:
				case TRUE:
				case NULL:
				/*case Tokens.UNDEFINED:
				case Tokens.NAN:
				case Tokens.INFINITY:*/
				case FALSE:
					if (cur != null) {wr.unexpected(w.val(), "type.get_able");} else {
						cur = Constant.valueOf(w);
						// string
						switch (cur.type()) {
							case 2:
							case -1:
								opFlag |= 2;
								break;
							default:
								opFlag |= 4;
								break;
						}
					}
					break;
				case colon:
					if ((exprFlag & 1536) == 0) wr.unexpected(w.val());
					if ((exprFlag & 1024) != 0) wr.retractWord();
					// ? :
					break o;
				// assign
				case assign:
					// has 2 and not has 16: opFlag & 18 != 2
					if (cur == null || (opFlag & 18) != 2) wr.unexpected(w.val());

					// Mark assign
					cur.mark_spec_op(ctx, 2);

					Expression right = read(ctx, (short) (exprFlag | 4096), null);

					if (right == null) {
						throw wr.err("empty.right_value");
					}

					if (!(cur instanceof LoadExpression)) throw wr.err("invalid_left_value");
					cur = new Assign((LoadExpression) cur, right);
					break;
				case add_assign:
				case div_assign:
				case and_assign:
				case lsh_assign:
				case mod_assign:
				case mul_assign:
				case rsh_assign:
				case rsh_unsigned_assign:
				case sub_assign:
				case xor_assign:
					// a &= 3;
					// =>
					// a = a & 3;

					if (cur == null || (opFlag & 18) != 2) wr.unexpected(w.val());

					// Mark assign-op
					cur.mark_spec_op(ctx, 3);

					short vtype = w.type();

					Expression expr = read(ctx, (short) (exprFlag | 4096), null);
					if (expr == null) {
						throw wr.err("empty.right_value");
					}

					if (!(cur instanceof LoadExpression)) throw wr.err("invalid_left_value");
					cur = new Assign((LoadExpression) cur, new Binary(assign2op(vtype), cur, expr));
					break;
				case dot: {
					if ((opFlag & 1) == 0) {
						opFlag |= 1;
						opFlag &= ~2;
					} else {wr.unexpected(".");}
				}
				break;
				case left_l_bracket:
					if (cur != null/* || (opFlag & 1) != 0*/) // at beginning
					{wr.unexpected("{");}
					cur = pythonCall(ctx, exprFlag);
					opFlag |= 2;
					break;

				// ( x )
				case left_s_bracket:
					// 1, (2), 16
					//if ((opFlag & 19) != 2)
					//    err(ctx, "(");
					if ((opFlag & 17) != 0) wr.unexpected("(");

					// bracket
					if (cur == null) {
						cur = read(ctx, (short) 256, null);
						if (cur == null) throw wr.err("empty.bracket");
					} else {
						if ((opFlag & 2) == 0) wr.unexpected("(");
						// function call
						List<Expression> args = Helpers.cast(this.sort);
						args.clear();

						while (true) {
							Expression e1 = read(ctx, (short) 16, null);
							if (e1 != null) {
								args.add(e1);
							} else {
								w = wr.nextWord();
								if (w.type() != right_s_bracket) {
									wr.unexpected(w.val(), ")");
								}
								break;
							}
						}

						cur = new Method(cur, args.isEmpty() ? Collections.emptyList() : new ArrayList<>(args), (opFlag & 8) != 0);
						args.clear();

						opFlag &= ~8;
					}
					break;
				default:
					if (isKeyword(w)) {
						wr.unexpected(w.val(), "type.expr");
					}
					// 'Clean' parameters pass to Delete expr
					// maybe && ?
					if ((opFlag & 16) == 0 & isSymbol(w)) {
						switch (symbolOperateCount(w.type())) {
							case 1:
								// logic_not inc dec rev

								boolean iod;
								switch (w.type()) {
									case inc:
									case dec:
										iod = true;
										break;
									default:
										iod = false;
										break;
								}

								if (cur != null) {
									// i++
									if (iod) {
										if (!(cur instanceof Field) && !(cur instanceof ArrayGet)) {
											throw wr.err("unary.expecting_variable");
										}

										cur = new UnaryAppendix(w.type(), cur);
										continue;
									} else {
										wr.unexpected(w.val());
									}
								}

								// ++i

								UnaryPrefix ul = new UnaryPrefix(w.type());
								if (pf != null) {
									String code = pf.setRight(ul);
									if (code != null) throw wr.err(code);
								} else {
									pfTop = ul;
								}
								pf = ul;

								break;
							case 2:
								if (cur != null) { // has right value
									if (pfTop != null) {

										String code = pf.setRight(cur);
										if (code != null) throw wr.err(code);

										tmp.add(pfTop);
										pf = pfTop = null;
									} else {
										tmp.add(cur);
									}
									wr.flag = GenericLexer.PARSE_SIGNED_NUMBER;
									cur = null;
									opFlag = 0;
								} else {
									switch (w.type()) {
										case add:
										case sub: {
											UnaryPrefix ul1 = new UnaryPrefix(w.type());
											if (pf != null) {
												String code = pf.setRight(ul1);
												if (code != null) throw wr.err(code);
											} else {
												pfTop = ul1;
											}
											pf = ul1;
										}
										continue;
										default:
											wr.unexpected(w.val(), "type.get_able");
									}
								}

								ordered.put(tmp.size(), symbolPriority(w));
								tmp.add(Operator.retain(w.type()));
								break;
							case 3:
								// ? :
								if (cur == null) {
									wr.unexpected(w.val(), "type.get_able");
								}
								Expression mid = read(ctx, (short) 512, null);
								if (mid == null) {
									wr.unexpected("empty.illegal");
								}
								Expression r = read(ctx, (short) (exprFlag | 4096), null);
								if (r == null) {
									wr.unexpected("empty.illegal");
								}
								tmp.add(new TripleIf(cur, mid, r));
								break;
							case 0:
								wr.unexpected(w.val());
								break;
						}
					} else {
						wr.unexpected(w.val());
					}
					break;
				case WordPresets.EOF:
					wr.unexpected("eof");
					break o; // useless
				case right_m_bracket:
					if ((exprFlag & 136) == 0) { // 128 / 8
						wr.unexpected("]");
					} else {
						if ((exprFlag & 128) != 0) // define array
						{wr.retractWord();}
						break o;
					}
					break;
				case right_l_bracket:
					if ((exprFlag & 64) == 0) {wr.unexpected("}");} else {
						wr.retractWord();
						break o;
					}
					break;
				case comma:
					if ((exprFlag & 6616) == 0) { // 8 / 16 / 64 / 128 / 256 / 2048 / 4096
						if (exprFlag != 0) // skip normal tag
						{wr.unexpected(",");}

						opFlag |= 32;
					} else {
						// 16 / 2048
						if ((exprFlag & 2056) != 0) // is !!NOT[function]CURRENTLY / array index / comma-link
						{wr.retractWord();}
					}
					break o;
				case right_s_bracket:
					if ((exprFlag & 272) == 0) // 16 / 256
					{wr.unexpected(")");} else {
						if ((exprFlag & 16) != 0) // is function
						{wr.retractWord();}
						break o;
					}
					break;
				case semicolon:
					break o;
			}
		}

		Int2IntMap tokens = ordered;

		if (cur != null) {
			if (pf != null) {
				String code = pf.setRight(cur);
				if (code != null) throw wr.err(code);

				cur = pfTop;
			}

			/*if ((opFlag & 16) != 0) {
				if (!tokens.isEmpty()) throw new RuntimeException("Error: A coding error!!! delete param should be clean access of variables such as a.b, this.a or a[some ? 'a' : 'b']: " + ordered);
				if (!(cur instanceof LoadExpression)) throw wr.err("delete.non_deletable:" + cur);
				if (!((LoadExpression) cur).setDeletion()) throw wr.err("delete.unable_variable");

				opFlag &= ~16;
			}*/

			tmp.add(cur);
		} else if (pf != null) {
			throw wr.err("unary.missing_operand");
		}

		if (w.type() == semicolon) {
			if ((opFlag & 8) != 0) {
				// 语法糖: 无参数调用
				if (cur == null) wr.unexpected(";", "type.variable");
				tmp.set(tmp.size() - 1, new Method(cur, Collections.emptyList(), true));
			}

			if ((opFlag & 16) != 0) {
				wr.unexpected(";", "type.variable");
			}
			if ((exprFlag & 59391) != 0) // 65535 - 2048 - 4096
			{wr.unexpected(";", description(exprFlag));}
			wr.retractWord();
		}

		Expression result = null;
		if (!tokens.isEmpty()) {
			List<Int2IntMap.Entry> sort = this.sort;

			for (int i = 0; i < tmp.size(); i++) {
				tmp.set(i, tmp.get(i).compress()); // pre-compress
			}

			sort.addAll(Helpers.cast(tokens.selfEntrySet()));
			sort.sort(sorter);

			for (int i = 0, e = sort.size(); i < e; i++) {
				if (i > 0) {
					int lv = sort.get(i - 1).getIntKey();
					for (int j = i; j < e; j++) {
						Int2IntMap.Entry v = sort.get(j);
						if (v.getIntKey() > lv) {
							v.Internal_Set_Key(v.getIntKey() - 2);
						}
					}
				}

				int v = sort.get(i).getIntKey();

				Expression l = tmp.get(v - 1), op, r;
				try {
					op = tmp.remove(v);
					r = tmp.remove(v);
				} catch (IndexOutOfBoundsException e1) {
					throw wr.err("binary.missing_operand");
				}

				result = new Binary(((SymTmp) op).operator, l, r);
				tmp.set(v - 1, result);
			}

			((Binary) result).setTarget(ifFalse);
			result = result.compress();

			tokens.clear();
			sort.clear();
		} else {
			result = tmp.isEmpty() ? null : tmp.get(0).compress();
		}

		tmp.clear();

		if ((opFlag & 32) != 0) {
			Chained cd = new Chained();
			cd.append(result);
			result = cd;

			boolean lastComma = false;

			cyl:
			while (true) {
				Expression e1 = read(ctx, (short) 2048, null);
				if (e1 != null) {
					lastComma = false;
					cd.append(e1);
				}
				switch ((w = wr.nextWord()).type()) {
					case comma:
						if (lastComma) {
							wr.unexpected(w.val());
						}
						lastComma = true;
						break;
					case semicolon:
						if (!lastComma) break cyl;
					default:
						wr.unexpected(w.val(), ";");
						break;
				}
			}
		}

		return result;
	}

	private static String description(short exprFlag) {
		if ((exprFlag & 8) != 0) return "delimiter.array_index";
		if ((exprFlag & 16) != 0) return "delimiter.func";
		if ((exprFlag & 32) != 0) return "delimiter.if";
		if ((exprFlag & 64) != 0) return "}";
		if ((exprFlag & 128) != 0) return "]";
		if ((exprFlag & 256) != 0) return ")";
		if ((exprFlag & 512) != 0) return "delimiter.triple";
		if ((exprFlag & 1024) != 0) return "delimiter.for";
		return "exprFlag." + exprFlag;
	}

	public void reset() {
		this.words.clear();
		this.sort.clear();
		this.ordered.clear();
	}

	private static short assign2op(short type) {
		switch (type) {
			case add_assign: return add;
			case div_assign: return div;
			case and_assign: return and;
			case lsh_assign: return lsh;
			case mod_assign: return mod;
			case mul_assign: return mul;
			case rsh_assign: return rsh;
			case rsh_unsigned_assign: return rsh_unsigned;
			case sub_assign: return sub;
			case xor_assign: return xor;
		}
		throw new IllegalStateException("Unknown assign type: " + type);
	}
}
