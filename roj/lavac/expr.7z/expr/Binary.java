package roj.lavac.expr;

import roj.asm.Opcodes;
import roj.asm.tree.insn.LabelInsnNode;
import roj.asm.type.Type;
import roj.concurrent.OperationDone;
import roj.config.word.NotStatementException;
import roj.lavac.parser.MethodPoetL;
import roj.lavac.parser.Symbol;

import javax.annotation.Nonnull;

/**
 * 操作符 - 二元操作 a + b
 *
 * @author Roj233
 * @since 2022/2/24 19:56
 */
public final class Binary implements Expression {
	final short operator;
	Expression left, right;
	LabelInsnNode target;

	public Binary(short operator, Expression left, Expression right) {
		switch (operator) {
			default:
				throw new IllegalArgumentException("Unsupported operator " + Symbol.byId(operator));
			case Symbol.pow:
			case Symbol.add:
			case Symbol.and:
			case Symbol.div:
			case Symbol.lsh:
			case Symbol.mod:
			case Symbol.mul:
			case Symbol.or:
			case Symbol.rsh:
			case Symbol.rsh_unsigned:
			case Symbol.sub:
			case Symbol.xor:
			case Symbol.logic_and:
			case Symbol.logic_or:
			case Symbol.lss:
			case Symbol.gtr:
			case Symbol.geq:
			case Symbol.leq:
			case Symbol.equ:
			case Symbol.neq:
				break;
		}
		this.operator = operator;
		this.left = left;
		this.right = right;
	}

	public int constNum() {
		int a = (left = left.compress()).isConstant() ? 1 : 0;
		if ((right = right.compress()).isConstant()) a++;
		return a;
	}

	@Override
	public void write(MethodPoetL tree, boolean noRet) {
		if (noRet) {
			switch (operator) {
				case Symbol.logic_or:
				case Symbol.logic_and:
					break;
				default:
					throw new NotStatementException();
			}
		}

		switch (operator) {
			case Symbol.logic_or:
			case Symbol.logic_and:
				break;
			default:
				left.write(tree, false);
				right.write(tree, false);
		}

		writeOperator(tree);
	}

	void writeOperator(MethodPoetL tree) {
		switch (operator) {
			case Symbol.lss:
				tree.noPar(Opcodes.IF_icmplt);
				break;
			case Symbol.gtr:
				tree.noPar(Opcodes.IF_icmpgt);
				break;
			case Symbol.geq:
				tree.noPar(Opcodes.IF_icmpge);
				break;
			case Symbol.leq:
				tree.noPar(Opcodes.IF_icmple);
				break;
			case Symbol.equ:
				tree.noPar(Opcodes.IF_icmpeq);
				break;
			case Symbol.neq:
				tree.noPar(Opcodes.IF_icmpne);
				break;
			case Symbol.add:
				tree.add();
				break;
			case Symbol.and:
				tree.and();
				break;
			case Symbol.logic_and: {
				// if a && b

				left.write(tree, false);
				if (target != null) {
					tree.if1(Opcodes.IFEQ, target);
					right.write(tree, false);
					tree.if1(Opcodes.IFEQ, target);
				} else {
					LabelInsnNode falseTo = new LabelInsnNode();
					LabelInsnNode fin = new LabelInsnNode();
					right.write(tree.If(falseTo, IfNode.TRUE), false);
					tree.If(falseTo, IfNode.TRUE).Load(KBool.TRUE).Goto(fin).Node(falseTo).Load(KBool.FALSE).node0(fin);
				}
			}
			break;
			case Symbol.logic_or: {
				LabelInsnNode falseTo = new LabelInsnNode();
				LabelInsnNode fin = new LabelInsnNode();

				// if a || b
				// = a ? a : b 而不是true/false ...

				left.write(tree, false);
				if (target != null) {
					right.write(tree.If(falseTo, IfNode.TRUE).Goto(fin).Node(falseTo), false);
					tree.If(target, IfNode.TRUE).node0(fin);
				} else {
					right.write(tree.Std(Opcode.DUP)
									// left, left
									.If(falseTo, IfNode.TRUE).Goto(fin).Node(falseTo).Std(Opcode.POP), false);
					tree.node(fin);
				}
			}
			break;
			case Symbol.or:
				tree.or();
				break;
			case Symbol.div:
				tree.div();
				break;
			case Symbol.lsh:
				tree.shl();
				break;
			case Symbol.mod:
				tree.mod();
				break;
			case Symbol.mul:
				tree.mul();
				break;
			case Symbol.rsh:
				tree.shr();
				break;
			case Symbol.rsh_unsigned:
				tree.ushr();
				break;
			case Symbol.sub:
				tree.sub();
				break;
			case Symbol.xor:
				tree.xor();
				break;
			case Symbol.pow:
				// todo POW
				throw new UnsupportedOperationException();
		}
	}

	@Nonnull
	@Override
	public Expression compress() {
		if ((left = left.compress()).isConstant() != (right = right.compress()).isConstant() || !right.isConstant()) {
			switch (operator) {
				case Symbol.logic_and:
					if (left.isConstant()) {
						if (left.asCst().asBool()) {
							// temporary ifload node
							return new AsBool(right);
						} else {
							return LDC.valueOf(false);
						}
					}
					break;
				case Symbol.logic_or:
					if (left.isConstant()) {
						if (left.asCst().asBool()) {
							return left.asCst();
						} else {
							return right;
						}
					}
			}
			return this;
		}

		final boolean d = left.type() == 1 || right.type() == 1;
		final LDC l = left.compress().asCst(), r = right.compress().asCst();

		switch (operator) {
			case Symbol.pow:
				return LDC.valueOf(Math.pow(l.asDouble(), r.asDouble()));
			case Symbol.lss:
				return LDC.valueOf(d ? l.asDouble() < r.asDouble() : l.asInt() < r.asInt());
			case Symbol.gtr:
				return LDC.valueOf(d ? l.asDouble() > r.asDouble() : l.asInt() > r.asInt());
			case Symbol.geq:
				return LDC.valueOf(d ? l.asDouble() >= r.asDouble() : l.asInt() >= r.asInt());
			case Symbol.leq:
				return LDC.valueOf(d ? l.asDouble() <= r.asDouble() : l.asInt() <= r.asInt());
			case Symbol.equ:
			case Symbol.neq:
				return LDC.valueOf((operator == Symbol.equ) == l.val().equalsTo(r.val()));
			case Symbol.feq:
				KType lv = l.val();
				KType rv = r.val();
				switch (l.type()) {
					case 0:
					case 1:
						return LDC.valueOf(r.type() < 2 && lv.equalsTo(rv));
					case 2:
						return LDC.valueOf(r.type() == 2 && l.asString().equals(r.asString()));
					case 3:
						return LDC.valueOf(lv == rv);
				}
				throw OperationDone.NEVER;
			case Symbol.add:
				switch (l.type()) {
					case 0:
					case 1:
						return r.type() == 2 ? LDC.valueOf(l.asString() + r.asString()) : LDC.valueOf(d ? KDouble.valueOf(l.asDouble() + r.asDouble()) : KInt.valueOf(l.asInt() + r.asInt()));
					case 2:
						return LDC.valueOf(l.asString() + r.asString());
					case 3:
						return LDC.valueOf(l.asInt() + r.asInt());
				}
				throw OperationDone.NEVER;
			case Symbol.sub:
				return LDC.valueOf(d ? KDouble.valueOf(l.asDouble() - r.asDouble()) : KInt.valueOf(l.asInt() - r.asInt()));
			case Symbol.div:
				return LDC.valueOf(l.asDouble() / r.asDouble());
			case Symbol.mul:
				return LDC.valueOf(d ? KDouble.valueOf(l.asDouble() * r.asDouble()) : KInt.valueOf(l.asInt() * r.asInt()));
			case Symbol.logic_and:
				return LDC.valueOf(l.asBool() && r.asBool());
			case Symbol.logic_or:
				return l.asBool() ? l : r;
			case Symbol.mod:
				return LDC.valueOf(KInt.valueOf(d ? (int) (l.asDouble() % r.asDouble()) : l.asInt() % r.asInt()));
			case Symbol.and:
				return LDC.valueOf(l.asInt() & r.asInt());
			case Symbol.lsh:
				return LDC.valueOf(l.asInt() << r.asInt());
			case Symbol.or:
				return LDC.valueOf(l.asInt() | r.asInt());
			case Symbol.rsh:
				return LDC.valueOf(l.asInt() >> r.asInt());
			case Symbol.rsh_unsigned:
				return LDC.valueOf(l.asInt() >>> r.asInt());
			case Symbol.xor:
				return LDC.valueOf(l.asInt() ^ r.asInt());
		}
		throw OperationDone.NEVER;
	}

	@Override
	public Type type() {
		if (left.type() == -1 || right.type() == -1) return -1;

		switch (operator) {
			case Symbol.lss:
			case Symbol.gtr:
			case Symbol.geq:
			case Symbol.leq:
			case Symbol.equ:
			case Symbol.feq:
			case Symbol.neq:
			case Symbol.logic_and:
			case Symbol.logic_or:
				return 3;
			case Symbol.and:
			case Symbol.or:
			case Symbol.xor:
			case Symbol.lsh:
			case Symbol.rsh:
			case Symbol.rsh_unsigned:
			case Symbol.mod:
				return 0;
			case Symbol.add:
			case Symbol.div:
			case Symbol.mul:
			case Symbol.sub:
			case Symbol.pow:
				return (byte) (right.type() == 1 || left.type() == 1 ? 1 : 0);
		}
		return -1;
	}

	@Override
	public String toString() {
		String l = left.toString();
		if (left.type() == -1) l = '(' + l + ')';
		String r = right.toString();
		if (right.type() == -1) r = '(' + r + ')';
		return l + Symbol.byId(operator) + r;
	}

	@Override
	public boolean isEqual(Expression left) {
		if (this == left) return true;
		if (!(left instanceof Binary)) return false;
		Binary b = (Binary) left;
		return b.left.isEqual(left) && b.right.isEqual(right) && b.operator == operator;
	}

	public void setTarget(LabelInsnNode ifFalse) {
		switch (operator) {
			case Symbol.logic_and: // only those need jump
			case Symbol.logic_or:
			case Symbol.lss:
			case Symbol.gtr:
			case Symbol.geq:
			case Symbol.leq:
			case Symbol.equ:
			case Symbol.neq:
			case Symbol.feq:
				this.target = ifFalse;
				break;
			default:
				if (ifFalse != null) throw new IllegalArgumentException("Operator not support: " + Symbol.byId(operator));
		}
	}
}
